"""
Module for data preprocessing and EDA
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
import warnings
warnings.filterwarnings('ignore')

class DataPreprocessor:
    def __init__(self, data_path):
        """
        Initialize the preprocessor with data path
        
        Parameters:
        data_path: Path to the CSV file
        """
        self.data_path = data_path
        self.df = None
        self.X = None
        self.y = None
        self.X_train = None
        self.X_test = None
        self.y_train = None
        self.y_test = None
        self.scaler = StandardScaler()
        
    def load_data(self):
        """Load the dataset"""
        print("Loading dataset...")
        self.df = pd.read_csv(self.data_path)
        print(f"Dataset shape: {self.df.shape}")
        print(f"Columns: {self.df.columns.tolist()[:10]}...")  # First 10 columns
        return self.df
    
    def explore_data(self):
        """Perform EDA on the dataset"""
        print("\n" + "="*50)
        print("EXPLORATORY DATA ANALYSIS")
        print("="*50)
        
        # Basic info
        print("\n1. Dataset Info:")
        print(self.df.info())
        
        print("\n2. Missing Values:")
        missing_values = self.df.isnull().sum()
        print(missing_values[missing_values > 0])
        
        print("\n3. Class Distribution:")
        class_dist = self.df['CLASS_LABEL'].value_counts()
        print(class_dist)
        
        # Visualizations
        self._create_visualizations()
        
        return class_dist
    
    def _create_visualizations(self):
        """Create EDA visualizations"""
        # Create directory for plots
        import os
        os.makedirs('visualizations', exist_ok=True)
        
        # 1. Class Distribution
        plt.figure(figsize=(10, 5))
        plt.subplot(1, 2, 1)
        self.df['CLASS_LABEL'].value_counts().plot(kind='bar', color=['green', 'red'])
        plt.title('Class Distribution (1=Legitimate, -1=Phishing)')
        plt.xlabel('Class')
        plt.ylabel('Count')
        
        # 2. Pie chart
        plt.subplot(1, 2, 2)
        self.df['CLASS_LABEL'].value_counts().plot(kind='pie', autopct='%1.1f%%', 
                                                    colors=['green', 'red'])
        plt.title('Class Distribution Percentage')
        plt.tight_layout()
        plt.savefig('visualizations/class_distribution.png')
        plt.show()
        
        # 3. Correlation Heatmap (top 20 features)
        plt.figure(figsize=(12, 10))
        numeric_cols = self.df.select_dtypes(include=[np.number]).columns
        top_features = numeric_cols[:20]  # First 20 features for readability
        correlation_matrix = self.df[top_features].corr()
        sns.heatmap(correlation_matrix, annot=False, cmap='coolwarm', center=0)
        plt.title('Correlation Heatmap (Top 20 Features)')
        plt.tight_layout()
        plt.savefig('visualizations/correlation_heatmap.png')
        plt.show()
        
        print("\n✓ Visualizations saved to 'visualizations/' folder")
    
    def preprocess_data(self):
        """Preprocess the data for modeling"""
        print("\n" + "="*50)
        print("DATA PREPROCESSING")
        print("="*50)
        
        # Remove ID column if exists
        if 'id' in self.df.columns:
            print("Removing 'id' column...")
            self.df = self.df.drop('id', axis=1)
        
        # Handle missing values
        print("Handling missing values...")
        missing_before = self.df.isnull().sum().sum()
        self.df = self.df.fillna(self.df.median())
        missing_after = self.df.isnull().sum().sum()
        print(f"Missing values filled: {missing_before} -> {missing_after}")
        
        # Separate features and target
        self.X = self.df.drop('CLASS_LABEL', axis=1)
        self.y = self.df['CLASS_LABEL']
        
        # Convert CLASS_LABEL: -1 (phishing) to 0, 1 (legitimate) to 1 for binary classification
        self.y = self.y.map({-1: 0, 1: 1})
        
        print(f"Features shape: {self.X.shape}")
        print(f"Target shape: {self.y.shape}")
        print(f"Class distribution after mapping:\n{self.y.value_counts()}")
        
        return self.X, self.y
    
    def split_and_scale(self, test_size=0.2, random_state=42):
        """Split data and apply scaling"""
        print("\n" + "="*50)
        print("TRAIN-TEST SPLIT & SCALING")
        print("="*50)
        
        # Split data
        self.X_train, self.X_test, self.y_train, self.y_test = train_test_split(
            self.X, self.y, test_size=test_size, random_state=random_state, stratify=self.y
        )
        
        print(f"Training set size: {self.X_train.shape}")
        print(f"Test set size: {self.X_test.shape}")
        
        # Scale features
        print("Applying StandardScaler...")
        self.X_train_scaled = self.scaler.fit_transform(self.X_train)
        self.X_test_scaled = self.scaler.transform(self.X_test)
        
        print("✓ Data preprocessing completed!")
        
        return self.X_train_scaled, self.X_test_scaled, self.y_train, self.y_test, self.scaler
