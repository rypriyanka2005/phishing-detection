"""
Module for Spectral Clustering - Optimized for speed
"""

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.cluster import SpectralClustering
from sklearn.decomposition import PCA
from sklearn.metrics import silhouette_score, adjusted_rand_score, normalized_mutual_info_score
import joblib
import os
import time
import warnings
warnings.filterwarnings('ignore')

class SpectralClusteringAnalysis:
    def __init__(self, X, y=None):
        """
        Initialize Spectral Clustering module
        """
        self.X = X
        self.y = y
        self.spectral = None
        self.labels = None
        self.pca_result = None
        self.n_clusters = None
        
    def find_optimal_clusters(self, max_clusters=5):
        """Find optimal number of clusters using Silhouette Score (Optimized)"""
        print("\n" + "="*50)
        print("SPECTRAL CLUSTERING - OPTIMAL CLUSTER SELECTION")
        print("="*50)
        
        silhouette_scores = []
        cluster_range = range(2, min(max_clusters + 1, 5))  # Max 4 clusters for speed
        
        print(f"Finding optimal number of clusters (testing k=2 to {max_clusters})...")
        
        for k in cluster_range:
            start_time = time.time()
            print(f"  Testing k={k}...", end=" ", flush=True)
            try:
                spectral = SpectralClustering(
                    n_clusters=k, 
                    random_state=42, 
                    affinity='rbf',
                    n_init=5,  # Reduced from 10
                    assign_labels='discretize',
                    n_neighbors=10  # Add this for efficiency
                )
                labels = spectral.fit_predict(self.X)
                score = silhouette_score(self.X, labels)
                silhouette_scores.append(score)
                elapsed = time.time() - start_time
                print(f"Score: {score:.4f} (took {elapsed:.1f}s)")
            except Exception as e:
                print(f"Error: {e}")
                silhouette_scores.append(0)
        
        # Create directory for plots
        os.makedirs('visualizations', exist_ok=True)
        
        # Plot Silhouette Scores
        plt.figure(figsize=(10, 6))
        plt.plot(list(cluster_range), silhouette_scores, 'bo-', linewidth=2, markersize=8)
        plt.xlabel('Number of Clusters (k)', fontsize=12)
        plt.ylabel('Silhouette Score', fontsize=12)
        plt.title('Spectral Clustering - Optimal k Selection', fontsize=14)
        plt.grid(True, alpha=0.3)
        
        # Mark the best k
        best_idx = np.argmax(silhouette_scores)
        best_k = list(cluster_range)[best_idx]
        plt.plot(best_k, silhouette_scores[best_idx], 'ro', markersize=12, 
                label=f'Optimal k = {best_k} (Score = {silhouette_scores[best_idx]:.4f})')
        plt.legend()
        
        plt.tight_layout()
        plt.savefig('visualizations/spectral_cluster_optimization.png', dpi=100, bbox_inches='tight')
        plt.close()
        
        print(f"\n✓ Optimal number of clusters: {best_k}")
        print(f"✓ Best Silhouette Score: {max(silhouette_scores):.4f}")
        
        return best_k, max(silhouette_scores)
    
    def perform_clustering(self, n_clusters=3):
        """Perform Spectral Clustering (Optimized)"""
        print(f"\n" + "="*50)
        print(f"PERFORMING SPECTRAL CLUSTERING with {n_clusters} clusters")
        print("="*50)
        
        self.n_clusters = n_clusters
        
        print("Running Spectral Clustering...")
        start_time = time.time()
        
        self.spectral = SpectralClustering(
            n_clusters=n_clusters,
            random_state=42,
            affinity='rbf',
            gamma=0.1,  # Reduced gamma for speed
            n_init=5,   # Reduced from 10
            assign_labels='discretize',
            n_neighbors=10  # Limit neighbors for efficiency
        )
        
        self.labels = self.spectral.fit_predict(self.X)
        
        elapsed = time.time() - start_time
        print(f"✓ Clustering completed in {elapsed:.1f} seconds")
        
        # Calculate silhouette score
        sil_score = silhouette_score(self.X, self.labels)
        print(f"✓ Silhouette Score: {sil_score:.4f}")
        
        # Analyze cluster distribution
        unique, counts = np.unique(self.labels, return_counts=True)
        print("\n📊 Cluster Distribution:")
        for cluster, count in zip(unique, counts):
            percentage = count / len(self.labels) * 100
            bar = '█' * int(percentage / 2)
            print(f"  Cluster {cluster}: {count:5d} samples ({percentage:5.1f}%) {bar}")
        
        return self.labels, sil_score
    
    def analyze_clusters_with_labels(self):
        """Analyze clusters against true labels if available"""
        if self.y is None:
            print("\n⚠️ No true labels available for analysis")
            return None, None
        
        print("\n" + "="*50)
        print("SPECTRAL CLUSTERING - LABEL ANALYSIS")
        print("="*50)
        
        # Create cross-tabulation
        cross_tab = pd.crosstab(self.y, self.labels)
        print("\n📊 Cross-tabulation (True Labels vs Clusters):")
        print(cross_tab)
        
        # Calculate purity
        purity = np.sum(np.max(cross_tab, axis=0)) / len(self.labels)
        print(f"\n✓ Cluster Purity: {purity:.4f} ({purity*100:.1f}%)")
        
        # Calculate Adjusted Rand Index
        ari = adjusted_rand_score(self.y, self.labels)
        print(f"✓ Adjusted Rand Index: {ari:.4f}")
        
        # Calculate Normalized Mutual Information
        nmi = normalized_mutual_info_score(self.y, self.labels)
        print(f"✓ Normalized Mutual Information: {nmi:.4f}")
        
        return purity, ari
    
    def visualize_clusters(self):
        """Visualize clusters using PCA"""
        print("\n" + "="*50)
        print("VISUALIZING SPECTRAL CLUSTERS")
        print("="*50)
        
        # Apply PCA for 2D visualization
        print("Applying PCA for visualization...")
        pca = PCA(n_components=2)
        self.pca_result = pca.fit_transform(self.X)
        
        # Create visualization
        fig, axes = plt.subplots(1, 2, figsize=(15, 6))
        
        # Plot 1: Spectral Clusters
        scatter1 = axes[0].scatter(self.pca_result[:, 0], self.pca_result[:, 1], 
                                   c=self.labels, cmap='viridis', alpha=0.6, s=20)
        axes[0].set_xlabel('First Principal Component', fontsize=12)
        axes[0].set_ylabel('Second Principal Component', fontsize=12)
        axes[0].set_title('Spectral Clustering Results (PCA Projection)', fontsize=14)
        plt.colorbar(scatter1, ax=axes[0], label='Spectral Cluster')
        axes[0].grid(True, alpha=0.3)
        
        # Plot 2: True Labels (if available)
        if self.y is not None:
            scatter2 = axes[1].scatter(self.pca_result[:, 0], self.pca_result[:, 1], 
                                       c=self.y, cmap='coolwarm', alpha=0.6, s=20)
            axes[1].set_xlabel('First Principal Component', fontsize=12)
            axes[1].set_ylabel('Second Principal Component', fontsize=12)
            axes[1].set_title('True Labels (for comparison)', fontsize=14)
            plt.colorbar(scatter2, ax=axes[1], label='True Label (0=Phish, 1=Legit)')
            axes[1].grid(True, alpha=0.3)
        
        plt.tight_layout()
        plt.savefig('visualizations/spectral_cluster_pca_visualization.png', dpi=100, bbox_inches='tight')
        plt.close()
        
        print("✓ Spectral cluster visualizations saved!")
    
    def compare_with_kmeans(self, kmeans_labels):
        """Compare Spectral Clustering results with K-Means"""
        print("\n" + "="*50)
        print("SPECTRAL CLUSTERING vs K-MEANS COMPARISON")
        print("="*50)
        
        ari = adjusted_rand_score(kmeans_labels, self.labels)
        nmi = normalized_mutual_info_score(kmeans_labels, self.labels)
        
        print(f"\n📊 Agreement between Spectral Clustering and K-Means:")
        print(f"  • Adjusted Rand Index: {ari:.4f}")
        print(f"  • Normalized Mutual Info: {nmi:.4f}")
        
        if ari > 0.8:
            print("  → Both methods found very similar clusters")
        elif ari > 0.6:
            print("  → Methods have moderate agreement")
        else:
            print("  → Methods found different patterns (Spectral found non-linear patterns!)")
        
        return ari, nmi
    
    def save_clustering_model(self, model_name='spectral_clustering.pkl'):
        """Save the clustering results"""
        os.makedirs('models', exist_ok=True)
        
        model_data = {
            'labels': self.labels,
            'n_clusters': self.n_clusters,
        }
        
        model_path = f'models/{model_name}'
        joblib.dump(model_data, model_path)
        print(f"✓ Spectral clustering results saved to {model_path}")
        return model_path
