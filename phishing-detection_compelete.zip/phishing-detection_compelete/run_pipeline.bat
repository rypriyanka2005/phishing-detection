@echo off
echo ========================================
echo Phishing Detection System Setup
echo ========================================
echo.

echo Installing requirements...
pip install -r requirements.txt

echo.
echo Running main pipeline...
python main_pipeline.py

echo.
echo Starting Streamlit UI...
streamlit run ui_app.py

pause